import { getDatabase } from "firebase/database";

const database = getDatabase();


import { getDatabase, ref, set } from "firebase/database";

function writeUserData(userId, inviterName, inviteid) {
  const db = getDatabase();
  set(ref(db, 'users/' + userId), {
    inviterName: inviterName,
    inviteid: inviteid,
}).thin(onFullFilled)=>{
	console.log("write");
},(onRejected)=>{
		console.log("onRejected");
	}
 

}