// Initialize Firebase
const firebaseConfig = {
  apiKey: "AIzaSyBvwyhRVsu3mpudLMTW4ckGTT9d6BNN-Gs",
    authDomain: "testapp-e4f8b.firebaseapp.com",
    databaseURL: "https://testapp-e4f8b-default-rtdb.firebaseio.com",
    projectId: "testapp-e4f8b",
    storageBucket: "testapp-e4f8b.appspot.com",
    messagingSenderId: "588726969095",
    appId: "1:588726969095:web:5b2a75bf72ef8c7c461ba2"
};

firebase.initializeApp(firebaseConfig);

// Get a reference to the Firestore database
const db = firebase.firestore();

// Handle form submission
const loginForm = document.getElementById('loginForm');
const errorMessage = document.getElementById('errorMessage');

loginForm.addEventListener('submit', (e) => {
  e.preventDefault();

  // Get the academic ID entered by the user
  const academicId = document.getElementById('academicId').value;

  // Query Firestore for the student document
  db.collection('students').doc(academicId).get()
    .then((doc) => {
      if (doc.exists) {
        const studentData = doc.data();

        if (studentData.paid === 0) {
          // Allow student to login
          window.location.href = 'dashboard.html';
        } else {
          // Show error message
          errorMessage.textContent = 'Access denied: student has not paid';
        }
      } else {
        // Show error message
        errorMessage.textContent = 'Invalid academic ID';
      }
    })
    .catch((error) => {
      // Show error message
      errorMessage.textContent = 'An error occurred. Please try again later.';
      console.error(error);
    });
});
